Flat Bot
========

Entry in PyWeek #5  <http://www.pyweek.org/5/>
Team: flatbot
Members: Richard Jones


DEPENDENCIES:

You will need:

  Python 1.5:           http://www.python.org/



RUNNING THE GAME:

On Windows or Mac OS X, locate the "run_game.pyw" file and double-click it.

Othewise open a terminal / console and "cd" to the game directory and run:

  python run_game.py



HOW TO PLAY THE GAME:

Move around using the cursor keys. Kick the football. Press UP to jump.



LICENSE:

flatbot is released under the GPL (until Cocos re-licenses to allow BSD)

