
import pyglet
from pyglet.gl import *
import cocos
from cocos import tiles
from cocos.director import director

class TileEditorControlLayer(cocos.layer.Layer):
    editor = None
    def on_text(self, s):
        if s != 'e': return False
        if self.editor is not None: return False

        pyglet.clock.unschedule(self.game.update)
        editor = TileEditorLayer(self.manager, self.level, 'data/level-tiles.xml',
            'level-tiles', self.edit_complete)
        self.scene.add(editor)
        director.window.push_handlers(editor)
        return True

    def edit_complete(self, layer):
        self.scene.remove(layer)
        director.window.remove_handlers(self.editor)
        self.editor = None
        pyglet.clock.schedule(self.game.update)


class TileEditorLayer(tiles.ScrollableLayer):
    def __init__(self, manager, map_layer, filename, id, on_done):
        super(TileEditorLayer, self).__init__()
        self.manager = manager
        self.manager.append(self)
        self.map_layer = map_layer
        tileset = cocos.tiles.load(filename)[id]
        tilesets = [
           (filename, ''),
        ]
        self.selector = TileSetWidget(tileset)
        self.highlight = None

        @self.selector.window.event
        def on_close():
            #self.map_layer.save_xml(tilesets)
            self.manager.remove(self)
            self.manager = None
            self.selector.close()
            on_done(self)
            return True

    def on_text_motion(self, motion):
        fx, fy = self.manager.fx, self.manager.fy
        if motion == pyglet.window.key.MOTION_UP:
            self.manager.force_focus(fx, fy+50)
        elif motion == pyglet.window.key.MOTION_DOWN:
            self.manager.force_focus(fx, fy-50)
        elif motion == pyglet.window.key.MOTION_LEFT:
            self.manager.force_focus(fx-50, fy)
        elif motion == pyglet.window.key.MOTION_RIGHT:
            self.manager.force_focus(fx+50, fy)
        else:
            return False
        return True

    def on_mouse_press(self, x, y, buttons, modifiers):
        x, y = self.map_layer.get_virtual_coordinates(x, y)
        cell = self.map_layer.get(x, y)
        cell.tile = self.selector.tileset[self.selector.current.tile_id]
        self.map_layer.set_dirty()
        self.manager.force_focus(self.manager.fx, self.manager.fy)
        return True

    def on_mouse_motion(self, x, y, dx, dy):
        x, y = self.map_layer.get_virtual_coordinates(x, y)
        cell = self.map_layer.get(x, y)
        if cell is not None:
            x, y = cell.origin[:2]
            self.highlight = (x, y, x+cell.width, y+cell.height)
        else:
            self.highlight = None
        return True

    def draw(self):
        if self.highlight is None:
            return
        glPushAttrib(GL_CURRENT_BIT | GL_ENABLE_BIT)
        glEnable(GL_BLEND)
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
        glColor4f(1, 1, 0, .3)
        glRectf(*self.highlight)
        glPopAttrib()

class TileSetWidget(object):
    def __init__(self, tileset):
        self.window = pyglet.window.Window(width=64,height=256,
            style=pyglet.window.Window.WINDOW_STYLE_TOOL)
        self.window.push_handlers(self)
        self.tileset = tileset
        y = 0
        self.batch = pyglet.graphics.Batch()
        self.sprites = []
        for n, k in enumerate(tileset):
            s = pyglet.sprite.Sprite(tileset[k].image, y=y, batch=self.batch)
            if not n:
                self.current = s
                s.color = (255, 200, 200)
            s.tile_id = k
            self.sprites.append(s)
            s.scale = 32. / s.width
            y += 32

    def on_mouse_press(self, x, y, buttons, modifiers):
        for s in self.sprites:
            if x < s.x or x > s.x + s.width: continue
            if y < s.y or y > s.y + s.height: continue
            self.current.color = (255, 255, 255)
            self.current = s
            s.color = (255, 200, 200)
            return True

    def on_draw(self):
        self.batch.draw()

    def close(self):
        self.window.pop_handlers()
        self.window.close()

