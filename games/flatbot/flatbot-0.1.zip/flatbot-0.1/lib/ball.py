
import pyglet

from cocos import tiles
from cocos.actions import *

from constants import *

class BallLayer(tiles.ScrollableLayer):
    def on_enter(self):
        self.im = pyglet.resource.image('ball.png')
        self.ball = ActionSprite(self.im, batch=self.batch)
        self.ball.resting = False
        self.ball.dx = self.ball.dy = 0

        self.add(self.ball, (500, 300))

        self.enable_step()

    def on_exit(self):
        self.disable_step()

    def step(self, dt):
        ball = self.ball
        level = self.level

        x, y = ball.position

        # handle ball x pos
        x += ball.dx * dt
        if x < 0:
            ball.dx *= -1
            x = 0
        elif x > level.px_width - ball.width:
            ball.dx *= -1
            x = level.px_width - ball.width

        # handle ball y pos
        y += ball.dy * dt
        cell1 = level.get(x, y)
        cell2 = level.get(x + ball.width, y)
        for cell in (cell1, cell2):
            if cell and cell.tile.properties.get('solid'):
                y = cell.y + cell.height
                ball.dy /= -2
                if abs(ball.dy) <= 1:
                    ball.dy = 0
                ball.resting = True
                break
        else:
            ball.resting = False
            ball.dy += GRAVITY
        if ball.resting:
            ball.dx -= ball.dx / 8.

        self.ball.position = (x, y)

