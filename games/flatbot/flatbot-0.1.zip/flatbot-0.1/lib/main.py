import pyglet
import cocos
from cocos import tiles

from cocos.director import director

import robot, ball, editor

def main():
    #director.init(width=700, height=440)
    #director.init(fullscreen=True)
    director.init(width=1024, height=440)
    #director.show_FPS = False

    pyglet.gl.glClearColor(1, 1, 1, 1)
    pyglet.gl.glDisable(pyglet.gl.GL_DEPTH_TEST)

    director.run(GameScene())


class GameScene(cocos.scene.Scene):

    def __init__(self):
        super(GameScene, self).__init__()

        self.manager = tiles.ScrollingManager(director.window)
        level = tiles.load('data/level1-map.xml')['map0']
        self.manager.append(level)
        self.add(level)

        self.robot = robot.RobotLayer()
        self.add(self.robot, z=1)
        self.manager.append(self.robot)

        self.ball = ball.BallLayer()
        self.add(self.ball, z=2)
        self.manager.append(self.ball)

        self.ball.level = level
        self.robot.level = level
        self.robot.ball = self.ball

        te = editor.TileEditorControlLayer()
        te.scene = self
        te.manager = self.manager
        te.level = level
        te.game = self
        self.add(te)

        self.do(FocusOnRobot())


class FocusOnRobot(cocos.actions.Action):

    def done(self): return False

    def step(self, dt):
        x, y = self.target.robot.position
        # XXX
        width = 200
        height = 200
        self.target.manager.set_focus(int(x) + width//2, int(y) + height//2)

