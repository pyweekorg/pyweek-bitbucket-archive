#! /usr/bin/env python

import sys
import os
import collections

import pyglet
import cocos
from cocos import tiles
from cocos.director import *
from cocos.actions import *

from constants import *

def centered_image(filename):
    image = pyglet.resource.image(filename)
    image.anchor_x = image.width//2
    image.anchor_y = image.height//2
    return image

class RobotLayer(tiles.ScrollableLayer):

    def on_enter(self):
        self.im_body = centered_image('robot-body.png')
        self.im_head = centered_image('robot-head.png')
        self.im_foot = centered_image('robot-foot.png')
        self.im_foot.anchor_y=0
        self.im_iris = centered_image('robot-iris.png')
        self.im_lant = centered_image('robot-left-antenna.png')
        self.im_lant.anchor_y=0
        self.im_rant = centered_image('robot-right-antenna.png')
        self.im_rant.anchor_y=0

        self.position = (200, 100)

        self.body = ActionSprite(self.im_body, batch=self.batch)
        self.add(self.body, (0, 100))
        self.body.rotation = 5

        # HEAD
        self.head = ActionSprite(self.im_head, batch=self.batch)
        self.add(self.head, (0, 170))
        self.lant = ActionSprite(self.im_lant, batch=self.batch)
        self.head.add(self.lant, (-20, self.head.height//2))
        self.rant = ActionSprite(self.im_rant, batch=self.batch)
        self.head.add(self.rant, (20, self.head.height//2))

        # FEET
        self.left_foot = ActionSprite(self.im_foot, batch=self.batch)
        self.add(self.left_foot, (-self.body.width//2, 0))
        self.mid_foot = ActionSprite(self.im_foot, batch=self.batch)
        self.add(self.mid_foot, (0, 0))
        self.right_foot = ActionSprite(self.im_foot, batch=self.batch)
        self.add(self.right_foot, (self.body.width//2, 0))

        self.liris = ActionSprite(self.im_iris, batch=self.batch)
        self.head.add(self.liris, (-20, 4))
        self.riris = ActionSprite(self.im_iris, batch=self.batch)
        self.head.add(self.riris, (22, 2))

        self.dx = self.dy = 0

        self.keyboard = collections.defaultdict(list)

        self.enable_step()

    def on_key_press(self, symbol, modifiers):
        self.keyboard[symbol] = True
    def on_key_release(self, symbol, modifiers):
        self.keyboard[symbol] = False

    def on_exit(self):
        self.disable_step()

    _jumping = False
    def do_jump(self, direction):
        if self._jumping or self._landing: return
        self._jumping = True

        self.dy = 500

        # animate the jump
        self.head.do(Jump(10, 0, 1, .5))
        self.left_foot.do(Jump(-20, 0, 1, .2))
        self.mid_foot.do(Jump(-20, 0, 1, .2))
        self.right_foot.do(Jump(-20, 0, 1, .2))

    _landing = False
    def do_land(self):
        self._jumping = False
        if self._landing: return
        self._landing = True
        self.do(Delay(.2) +
            CallFuncS(lambda self: setattr(self, '_landing', False)))
        self.head.do(Jump(-10, 0, 1, .2))
        self.body.do(Jump(-20, 0, 1, .2))

    def step(self, dt):
        self.dx = 0
        if self.keyboard[pyglet.window.key.MOTION_LEFT]:
            self.dx -= 1
        if self.keyboard[pyglet.window.key.MOTION_RIGHT]:
            self.dx += 1

        level = self.level

        x, y = self.position

        # XXX
        width = 100

        # handle player x pos
        if self.dx:
            x += self.dx * 200 * dt
            if x < 0:
                x = 0
                self.dx = 0
            elif x > level.px_width - width:
                x = level.px_width - width
                self.dx = 0

        # handle player y pos
        y += self.dy * dt
        cell1 = level.get(x, y)
        cell2 = level.get(x + width, y)
        for cell in (cell1, cell2):
            if cell and cell.tile.properties.get('solid'):
                y = cell.y + cell.height
                self.dy = 0
                if self._jumping and not self._landing:
                    self.flush()
                    self.do_land()
                break
        else:
            self.dy += GRAVITY

        self.position = (int(x), int(y))

        ball = self.ball.ball

        # handle kick - XXX handle when ball was inside player last update
        bx, by = self.body.x, self.body.y
        sx, sy = x, y
        x, y = self.left_foot.position
        y += by + sy

        if y >= ball.y and y < ball.y + ball.height:
            width = self.left_foot.width
            x += bx + sx - width/2
            rhs = self.right_foot.position[0]
            rhs += bx + sx + width/2
            if x < ball.x + ball.width and x > ball.x:
                if self.dx < 0: speed = 400
                elif self.dx > 0: speed = 100
                else: speed = 200
                ball.dx = -200
                ball.dy = speed

            elif rhs < ball.x + ball.width and rhs > ball.x:
                if self.dx > 0: speed = 400
                elif self.dx < 0: speed = 100
                else: speed = 200
                ball.dx = 200
                ball.dy = speed

    def on_text_motion(self, motion):
        if motion == pyglet.window.key.MOTION_UP:
            self.do_jump(self.dx)
            return True


